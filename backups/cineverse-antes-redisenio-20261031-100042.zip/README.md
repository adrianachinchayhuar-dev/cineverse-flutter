# CineVerse · Laboratorio semanas 9 y 10

Aplicación Flutter con diseño móvil vertical, tema oscuro y acentos rojos. En escritorio conserva un ancho máximo de 480 px. El catálogo contiene 10 películas ficticias con fotografías ilustrativas: no son pósteres oficiales. No reproduce videos.

## Ejecutar

```sh
flutter pub get
flutter run -d chrome
```

## Archivos y explicación para la sustentación

| Archivo | Responsabilidad y requisitos |
| --- | --- |
| `lib/main.dart` | Inicio, `MaterialApp`, ruta `/`, `ThemeData` global y ancho móvil adaptable. Roboto es la fuente general. |
| `lib/data/peliculas.dart` | Catálogo `List<Map<String, dynamic>>` de 10 películas y lista de categorías. `where` permite filtrar por género. |
| `lib/screens/principal.dart` | Inicio, Explorar y Mi lista en una navegación inferior. `ListView` vertical; tres secciones con `ListView.builder` horizontal; categorías y películas con `ListTile`. Mantiene favoritos mediante una lista de identificadores y `setState`, sin persistencia. Abre detalles con `Navigator.push` y `MaterialPageRoute`, con nombre `/detalle/id`. |
| `lib/screens/detalle.dart` | Imagen, título, año, género, descripción y botón agregar/quitar. Recibe un callback para actualizar favoritos en la pantalla principal. Vuelve mediante `Navigator.pop`. |
| `lib/widgets/pelicula_widgets.dart` | `Card` reutilizable con `InkWell`; `Image.asset` para rutas locales e `Image.network` para HTTPS. `errorBuilder` muestra un icono con mensaje accesible si falla una imagen. |
| `pubspec.yaml` | Recursos locales y familias Poppins (regular y semibold), Roboto y Jacquard. Sin dependencias adicionales de ejecución. |
| `assets/images/` | Cinco fotografías JPEG reales incluidas. |
| `assets/fonts/` | Cuatro archivos TTF y licencias OFL de las tres familias. |
| `test/widget_test.dart` | Pruebas de navegación, filtros, favoritos y renderizado móvil. Reemplaza la prueba del contador inicial. |
| `web/index.html` | Nombre y descripción de CineVerse en el navegador. |

Poppins se aplica explícitamente en títulos y tarjetas. Roboto se aplica al texto general y a la sinopsis. Jacquard aparece en “Historias para perderse” al final del Inicio y en “Un universo de historias” en el detalle. Desplázate para mostrar estos elementos durante la exposición.

## Recursos incluidos

No falta ninguna imagen local ni fuente. Los archivos `orbita.jpg`, `bosque.jpg`, `ciudad.jpg`, `montana.jpg` y `oceano.jpg` están incorporados. Las cinco películas restantes usan URLs directas de `images.unsplash.com`, declaradas en el catálogo; requieren Internet y pueden mostrar el indicador de error si el servidor o la conexión fallan.

Las fuentes proceden del repositorio oficial de Google Fonts: https://github.com/google/fonts (carpetas `ofl/poppins`, `ofl/roboto` y `ofl/jacquard24`). Las licencias se incluyen junto a los TTF. Las fotografías ilustrativas proceden de Unsplash; los identificadores originales de las locales son:

- Órbita: `photo-1446776811953-b23d57bd21aa`.
- El bosque secreto: `photo-1448375240586-882707db888b`.
- Ciudad neón: `photo-1519608487953-e999c86e7455`.
- La última cumbre: `photo-1464822759023-fed622ff2c3b`.
- Azul profundo: `photo-1518837695005-2083093ee35b`.

## Verificación

- `flutter pub get`: ejecutado correctamente.
- `flutter analyze`: sin incidencias.
- `flutter test`: tres pruebas aprobadas. Se comprueban detalle/regreso, agregar/quitar favoritos y filtro de Animación a 390 × 844; Inicio y desplazamiento a 320 × 800 y 480 × 800 sin errores de renderizado.
- `flutter build web`: compilación web verificada.
- `flutter run -d chrome --web-port=7357`: Chrome inició y se conectó al servicio de depuración; Flutter confirmó la ejecución de `main`.

Las pruebas de widgets bloquean HTTP por diseño: verifican también que las imágenes remotas fallidas muestren el indicador sin romper el diseño, pero no certifican su descarga real en Chrome. No se afirma una revisión manual completa de todos los controles en Chrome. Los favoritos se conservan durante la ejecución y se vacían al reiniciar o recargar, según lo solicitado.

## Recorrido sugerido

1. En Inicio, pulsa “Ver detalles”, agrega Órbita y vuelve.
2. Abre Mi lista y comprueba que aparece. Puedes quitarla con la X o desde el detalle.
3. En Explorar, selecciona cada género y abre una película.
4. Vuelve a Inicio, desplaza las filas horizontalmente y baja hasta el texto decorativo Jacquard.
5. Abre una película remota para demostrar `Image.network` y una local para demostrar `Image.asset`.

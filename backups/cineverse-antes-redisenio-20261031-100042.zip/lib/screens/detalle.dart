import 'package:flutter/material.dart';
import '../widgets/pelicula_widgets.dart';

class DetallePelicula extends StatefulWidget {
  const DetallePelicula({
    super.key,
    required this.pelicula,
    required this.guardada,
    required this.alternar,
  });
  final Map<String, dynamic> pelicula;
  final bool guardada;
  final VoidCallback alternar;

  @override
  State<DetallePelicula> createState() => _DetallePeliculaState();
}

class _DetallePeliculaState extends State<DetallePelicula> {
  late bool guardada = widget.guardada;

  @override
  Widget build(BuildContext context) {
    final pelicula = widget.pelicula;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          tooltip: 'Volver',
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Acerca de la película',
          style: TextStyle(fontFamily: 'Poppins', fontSize: 16),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: SizedBox(
              height: 360,
              child: ImagenPelicula(pelicula: pelicula),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'CINEVERSE · SELECCIÓN',
            style: TextStyle(
              color: Color(0xFFFF354B),
              letterSpacing: 2,
              fontSize: 11,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            pelicula['titulo'] as String,
            style: const TextStyle(
              fontFamily: 'Poppins',
              fontSize: 29,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '${pelicula['anio']}   •   ${pelicula['genero']}',
            style: const TextStyle(color: Colors.white60),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: () {
              widget.alternar();
              setState(() => guardada = !guardada);
            },
            icon: Icon(guardada ? Icons.check : Icons.add),
            label: Text(guardada ? 'Quitar de Mi lista' : 'Agregar a Mi lista'),
          ),
          const SizedBox(height: 28),
          const Text(
            'La historia',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 19,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            pelicula['descripcion'] as String,
            style: const TextStyle(
              fontFamily: 'Roboto',
              color: Color(0xFFB8BAC4),
              fontSize: 16,
              height: 1.8,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Un universo de historias',
            style: TextStyle(
              fontFamily: 'Jacquard',
              fontSize: 30,
              color: Colors.white54,
            ),
          ),
        ],
      ),
    );
  }
}

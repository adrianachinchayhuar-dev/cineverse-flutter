import 'package:flutter/material.dart';
import '../data/peliculas.dart';
import '../widgets/pelicula_widgets.dart';
import 'detalle.dart';

class PantallaPrincipal extends StatefulWidget {
  const PantallaPrincipal({super.key});
  @override
  State<PantallaPrincipal> createState() => _PantallaPrincipalState();
}

class _PantallaPrincipalState extends State<PantallaPrincipal> {
  int pestana = 0;
  String categoria = 'Acción';
  // El estado vive en esta pantalla y se comparte mediante callbacks sencillos.
  // Al cerrar la aplicación, esta lista se pierde intencionalmente.
  final List<int> miLista = [];

  void alternar(Map<String, dynamic> pelicula) {
    final id = pelicula['id'] as int;
    setState(() => miLista.contains(id) ? miLista.remove(id) : miLista.add(id));
  }

  void abrirDetalle(Map<String, dynamic> pelicula) {
    Navigator.push(
      context,
      MaterialPageRoute<void>(
        settings: RouteSettings(name: '/detalle/${pelicula['id']}'),
        builder: (context) => DetallePelicula(
          pelicula: pelicula,
          guardada: miLista.contains(pelicula['id']),
          alternar: () => alternar(pelicula),
        ),
      ),
    );
  }

  Widget titulo(String texto) => Text(
    texto,
    style: const TextStyle(
      fontFamily: 'Poppins',
      fontSize: 21,
      fontWeight: FontWeight.w600,
    ),
  );

  Widget fila(String nombre, List<Map<String, dynamic>> lista) {
    return Padding(
      padding: const EdgeInsets.only(top: 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: titulo(nombre),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 204,
            child: ListView.builder(
              padding: const EdgeInsets.only(left: 20, right: 8),
              scrollDirection: Axis.horizontal,
              itemCount: lista.length,
              itemBuilder: (context, index) => TarjetaPelicula(
                pelicula: lista[index],
                onTap: () => abrirDetalle(lista[index]),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget inicio() {
    final destacada = peliculas.first;
    return ListView(
      key: const PageStorageKey('inicio'),
      padding: const EdgeInsets.only(bottom: 28),
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 12, 20, 18),
          child: Row(
            children: [
              Icon(Icons.circle, size: 6, color: Color(0xFFFF354B)),
              SizedBox(width: 8),
              Flexible(
                child: Text(
                  'TU PRÓXIMA GRAN HISTORIA',
                  style: TextStyle(
                    fontSize: 10,
                    letterSpacing: 2,
                    color: Colors.white60,
                  ),
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: SizedBox(
              height: 420,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ImagenPelicula(pelicula: destacada),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Color(0xFF0B0C10)],
                        stops: [0.15, 1],
                      ),
                    ),
                  ),
                  Positioned(
                    top: 16,
                    left: 16,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF354B),
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: const Text(
                        'DESTACADA DE LA SEMANA',
                        style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 20,
                    right: 20,
                    bottom: 18,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'EL UNIVERSO TIENE UN SECRETO',
                          style: TextStyle(
                            fontSize: 9,
                            letterSpacing: 1.8,
                            color: Colors.white70,
                          ),
                        ),
                        const Text(
                          'ÓRBITA',
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 38,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 2,
                          ),
                        ),
                        const Text(
                          '2025   •   Ciencia ficción',
                          style: TextStyle(color: Colors.white70, fontSize: 12),
                        ),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: () => abrirDetalle(destacada),
                          icon: const Icon(Icons.info_outline, size: 19),
                          label: const Text('Ver detalles'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        fila('Tendencias', peliculas.take(5).toList()),
        fila('Recomendadas', [
          peliculas[5],
          peliculas[3],
          peliculas[7],
          peliculas[9],
        ]),
        fila(
          'Animación',
          peliculas.where((p) => p['genero'] == 'Animación').toList(),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 32, 20, 8),
          child: Text(
            'Historias para perderse',
            style: TextStyle(
              fontFamily: 'Jacquard',
              fontSize: 32,
              color: Colors.white54,
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            'Un catálogo imaginario. Una pasión real por el cine.',
            style: TextStyle(fontSize: 11, color: Colors.white38),
          ),
        ),
      ],
    );
  }

  Widget peliculaEnLista(Map<String, dynamic> pelicula, {bool quitar = false}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.all(12),
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: SizedBox(
            width: 50,
            height: 70,
            child: ImagenPelicula(pelicula: pelicula),
          ),
        ),
        title: Text(
          pelicula['titulo'] as String,
          style: const TextStyle(
            fontFamily: 'Poppins',
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Text(
          '${pelicula['anio']} · ${pelicula['genero']}',
          style: const TextStyle(fontSize: 11, color: Colors.white54),
        ),
        trailing: quitar
            ? IconButton(
                tooltip: 'Quitar ${pelicula['titulo']}',
                onPressed: () => alternar(pelicula),
                icon: const Icon(Icons.close),
              )
            : const Icon(Icons.chevron_right),
        onTap: () => abrirDetalle(pelicula),
      ),
    );
  }

  Widget explorar() {
    final filtradas = peliculas.where((p) => p['genero'] == categoria).toList();
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        titulo('Encuentra tu historia'),
        const SizedBox(height: 6),
        const Text(
          'Elige un género y descubre algo nuevo.',
          style: TextStyle(color: Colors.white54),
        ),
        const SizedBox(height: 24),
        // Cada categoría es un ListTile que filtra nuestra lista de mapas.
        ...categorias.map(
          (nombre) => Card(
            child: ListTile(
              selected: nombre == categoria,
              selectedTileColor: const Color(0xFF351B25),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              leading: Icon(
                [
                  Icons.bolt,
                  Icons.auto_awesome,
                  Icons.rocket_launch,
                  Icons.landscape,
                ][categorias.indexOf(nombre)],
              ),
              title: Text(
                nombre,
                style: const TextStyle(fontFamily: 'Poppins', fontSize: 14),
              ),
              trailing: Icon(
                nombre == categoria
                    ? Icons.keyboard_arrow_down
                    : Icons.chevron_right,
              ),
              onTap: () => setState(() => categoria = nombre),
            ),
          ),
        ),
        const SizedBox(height: 28),
        titulo(categoria),
        Text(
          '${filtradas.length} películas',
          style: const TextStyle(color: Colors.white54),
        ),
        const SizedBox(height: 16),
        ...filtradas.map((p) => peliculaEnLista(p)),
      ],
    );
  }

  Widget guardadas() {
    final seleccionadas = peliculas
        .where((p) => miLista.contains(p['id']))
        .toList();
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        titulo('Tus próximas favoritas'),
        Text(
          '${seleccionadas.length} películas en Mi lista',
          style: const TextStyle(color: Colors.white54),
        ),
        const SizedBox(height: 24),
        if (seleccionadas.isEmpty) ...[
          const SizedBox(height: 60),
          const Icon(
            Icons.bookmark_border_rounded,
            size: 64,
            color: Color(0xFFFF354B),
          ),
          const SizedBox(height: 20),
          const Center(
            child: Text(
              'Tu historia empieza aquí',
              style: TextStyle(fontFamily: 'Poppins', fontSize: 18),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Agrega películas desde sus detalles y encuéntralas aquí.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white54),
          ),
          const SizedBox(height: 24),
          Center(
            child: FilledButton(
              onPressed: () => setState(() => pestana = 1),
              child: const Text('Explorar películas'),
            ),
          ),
        ] else
          ...seleccionadas.map((p) => peliculaEnLista(p, quitar: true)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text.rich(
          TextSpan(
            children: [
              TextSpan(
                text: 'Cine',
                style: TextStyle(color: Color(0xFFFF354B)),
              ),
              TextSpan(text: 'Verse'),
            ],
          ),
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            fontSize: 25,
            letterSpacing: -1,
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 20),
            child: Icon(Icons.movie_filter_outlined, color: Color(0xFFFF354B)),
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        child: [inicio, explorar, guardadas][pestana](),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF121318),
        indicatorColor: const Color(0xFF49202B),
        selectedIndex: pestana,
        onDestinationSelected: (index) => setState(() => pestana = index),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Inicio',
          ),
          NavigationDestination(
            icon: Icon(Icons.explore_outlined),
            selectedIcon: Icon(Icons.explore),
            label: 'Explorar',
          ),
          NavigationDestination(
            icon: Icon(Icons.bookmark_border),
            selectedIcon: Icon(Icons.bookmark),
            label: 'Mi lista',
          ),
        ],
      ),
    );
  }
}

// Catálogo ficticio: una lista de mapas permite practicar List y Map sin APIs.
final List<Map<String, dynamic>> peliculas = [
  {
    'id': 1,
    'titulo': 'Órbita',
    'genero': 'Ciencia ficción',
    'anio': 2025,
    'imagen': 'assets/images/orbita.jpg',
    'descripcion':
        'Una astronauta recibe una señal imposible desde el lado oscuro de un planeta. Para volver a casa, tendrá que descubrir quién la está llamando.',
  },
  {
    'id': 2,
    'titulo': 'El bosque secreto',
    'genero': 'Animación',
    'anio': 2024,
    'imagen': 'assets/images/bosque.jpg',
    'descripcion':
        'Una pequeña guardiana y un zorro de luz emprenden un viaje para devolver los colores a su bosque.',
  },
  {
    'id': 3,
    'titulo': 'Ciudad neón',
    'genero': 'Acción',
    'anio': 2025,
    'imagen': 'assets/images/ciudad.jpg',
    'descripcion':
        'Una mensajera tiene una noche para cruzar la ciudad y entregar la prueba que cambiará su destino.',
  },
  {
    'id': 4,
    'titulo': 'La última cumbre',
    'genero': 'Aventura',
    'anio': 2023,
    'imagen': 'assets/images/montana.jpg',
    'descripcion':
        'Dos hermanos vuelven a las montañas para completar la expedición que su padre dejó inconclusa.',
  },
  {
    'id': 5,
    'titulo': 'Azul profundo',
    'genero': 'Aventura',
    'anio': 2024,
    'imagen': 'assets/images/oceano.jpg',
    'descripcion':
        'Una exploradora sigue un mapa submarino hasta una isla que desaparece con cada amanecer.',
  },
  {
    'id': 6,
    'titulo': 'Más allá del sol',
    'genero': 'Ciencia ficción',
    'anio': 2026,
    'imagen':
        'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=600&q=80',
    'descripcion':
        'La tripulación de una nave descubre un nuevo hogar y un misterio que podría cambiar la historia de la Tierra.',
  },
  {
    'id': 7,
    'titulo': 'Pequeños gigantes',
    'genero': 'Animación',
    'anio': 2025,
    'imagen':
        'https://images.unsplash.com/photo-1472396961693-142e6e269027?w=600&q=80',
    'descripcion':
        'Un grupo de animales diminutos demuestra que la valentía no depende del tamaño.',
  },
  {
    'id': 8,
    'titulo': 'Ruta de escape',
    'genero': 'Acción',
    'anio': 2024,
    'imagen':
        'https://images.unsplash.com/photo-1500534623283-312aade485b7?w=600&q=80',
    'descripcion':
        'Una conductora y un desconocido deben confiar el uno en el otro para escapar de una persecución a través del desierto.',
  },
  {
    'id': 9,
    'titulo': 'El reino de las nubes',
    'genero': 'Animación',
    'anio': 2026,
    'imagen':
        'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=600&q=80',
    'descripcion':
        'Una inventora construye una máquina voladora para encontrar un reino escondido entre las nubes.',
  },
  {
    'id': 10,
    'titulo': 'Horizonte perdido',
    'genero': 'Aventura',
    'anio': 2025,
    'imagen':
        'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&q=80',
    'descripcion':
        'Una expedición sigue las estrellas hacia un valle que no aparece en ningún mapa.',
  },
];

const categorias = ['Acción', 'Animación', 'Ciencia ficción', 'Aventura'];

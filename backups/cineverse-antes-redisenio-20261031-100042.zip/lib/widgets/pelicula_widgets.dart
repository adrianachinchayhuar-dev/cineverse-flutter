import 'package:flutter/material.dart';

class ImagenPelicula extends StatelessWidget {
  const ImagenPelicula({
    super.key,
    required this.pelicula,
    this.fit = BoxFit.cover,
  });
  final Map<String, dynamic> pelicula;
  final BoxFit fit;

  @override
  Widget build(BuildContext context) {
    final ruta = pelicula['imagen'] as String;
    // Ambas fuentes de imágenes tienen un indicador si el recurso falla.
    Widget error(BuildContext context, Object error, StackTrace? stack) {
      return const ColoredBox(
        color: Color(0xFF242631),
        child: Center(
          child: Tooltip(
            message: 'Imagen no disponible',
            child: Icon(
              Icons.broken_image_outlined,
              color: Colors.white54,
              size: 24,
            ),
          ),
        ),
      );
    }

    return ruta.startsWith('https://')
        ? Image.network(
            ruta,
            fit: fit,
            width: double.infinity,
            height: double.infinity,
            errorBuilder: error,
          )
        : Image.asset(
            ruta,
            fit: fit,
            width: double.infinity,
            height: double.infinity,
            errorBuilder: error,
          );
  }
}

class TarjetaPelicula extends StatelessWidget {
  const TarjetaPelicula({
    super.key,
    required this.pelicula,
    required this.onTap,
  });
  final Map<String, dynamic> pelicula;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 142,
      child: Card(
        margin: const EdgeInsets.only(right: 12, bottom: 4),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Stack(
            fit: StackFit.expand,
            children: [
              ImagenPelicula(pelicula: pelicula),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xF508090D)],
                    stops: [0.35, 1],
                  ),
                ),
              ),
              Positioned(
                left: 10,
                right: 10,
                bottom: 12,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      pelicula['titulo'] as String,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${pelicula['anio']}',
                      style: const TextStyle(
                        color: Colors.white60,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:laboratorio_flutter/main.dart';

void main() {
  testWidgets('Detalle, favoritos, categorías y regreso funcionan en móvil', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(const CineVerseApp());
    await tester.pumpAndSettle();
    await tester.tap(find.text('Ver detalles'));
    await tester.pumpAndSettle();
    expect(find.text('La historia'), findsOneWidget);
    await tester.ensureVisible(find.text('Agregar a Mi lista'));
    await tester.tap(find.text('Agregar a Mi lista'));
    await tester.pumpAndSettle();
    expect(find.text('Quitar de Mi lista'), findsOneWidget);
    await tester.tap(find.byTooltip('Volver'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Mi lista'));
    await tester.pumpAndSettle();
    expect(find.text('Órbita'), findsOneWidget);
    await tester.tap(find.byTooltip('Quitar Órbita'));
    await tester.pumpAndSettle();
    expect(find.text('Tu historia empieza aquí'), findsOneWidget);
    await tester.tap(find.text('Explorar películas'));
    await tester.pumpAndSettle();
    expect(find.text('Ciudad neón'), findsOneWidget);
    await tester.tap(find.text('Animación').first);
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(
      find.text('El bosque secreto'),
      150,
      scrollable: find.byType(Scrollable).first,
    );
    expect(find.text('El bosque secreto'), findsOneWidget);
    // Los errores de renderizado hacen fallar la prueba automáticamente.
  });

  for (final ancho in [320.0, 480.0]) {
    testWidgets('Inicio sin desbordamiento a $ancho píxeles', (tester) async {
      tester.view.physicalSize = Size(ancho, 800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(const CineVerseApp());
      await tester.pumpAndSettle();
      await tester.drag(find.byType(Scrollable).first, const Offset(0, -650));
      await tester.pumpAndSettle();
      // Los errores de renderizado hacen fallar la prueba automáticamente.
    });
  }
}
